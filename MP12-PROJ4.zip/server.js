const express = require('express');
const path = require('path');
const cors = require('cors');
const axios = require('axios');
const mysql = require('mysql2');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3000;

// Enable CORS
app.use(cors());

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// MySQL connection setup
const db = mysql.createConnection({
    host: process.env.DB_HOST, // e.g., 'localhost'
    user: process.env.DB_USER, // e.g., 'root'
    password: process.env.DB_PASSWORD, // your MySQL password
    database: process.env.DB_NAME // the database name, e.g., 'explore'
});

db.connect((err) => {
    if (err) {
        console.error("Error connecting to the database:", err.message);
    } else {
        console.log("Connected to the MySQL database");
    }
});

// Create the table if it doesn't exist
const createTableQuery = `
    CREATE TABLE IF NOT EXISTS submits (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        address TEXT NOT NULL,
        categories TEXT NOT NULL
    );
`;

db.query(createTableQuery, (err) => {
    if (err) {
        console.error("Error creating table:", err.message);
    } else {
        console.log("Table 'submits' ensured in the database.");
    }
});

// API route for fetching description from Wikipedia
app.get('/api/description', async (req, res) => {
    const poblacion = req.query.poblacion; // Get town name from query parameter

    if (!poblacion) {
        return res.status(400).json({ error: 'Missing poblacion query parameter' });
    }

    try {
        const response = await axios.get(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(poblacion)}`);
        res.json(response.data);
    } catch (error) {
        console.error(error); // Log the error for debugging purposes
        res.status(500).json({ error: 'Failed to fetch description from Wikipedia' });
    }
});

// API route for fetching data from Geoapify API
app.get('/api/geoapify', async (req, res) => {
    const geoapifyKey = process.env.GEOAPIFY_KEY;  // Get the Geoapify API key from environment variables
    const { lat, lon } = req.query;  // Get latitude and longitude from query parameters
    const categories = "tourism,leisure,accommodation,catering,entertainment";

    // Validate latitude and longitude
    if (!lat || !lon) {
        return res.status(400).json({ error: 'Missing lat or lon query parameter' });
    }

    try {
        let placesData = [];
        let nextUrl = `https://api.geoapify.com/v2/places?categories=${categories}&filter=circle:${lon},${lat},10000&limit=500&apiKey=${geoapifyKey}`;

        // Fetch multiple pages if "next" is present
        while (nextUrl) {
            const response = await axios.get(nextUrl);
            const data = response.data;

            placesData = placesData.concat(data.features); // Append the features to the results

            // Check if there is a next page
            nextUrl = data.next ? data.next : null; // If "next" exists, update the URL for the next request
        }

        // Return all the fetched data
        res.json({ features: placesData });

    } catch (error) {
        console.error('Error fetching from Geoapify:', error);  // Log the error
        res.status(500).json({ error: 'Failed to fetch data from Geoapify' });
    }
});

// API route to manually save places
app.post('/api/places-manual', express.json(), (req, res) => {
    const { name, address, categories } = req.body;

    if (!name || !address || !categories) {
        return res.status(400).json({ error: 'Missing required fields (name, address, or categories)' });
    }

    const stmt = `INSERT INTO submits (name, address, categories) VALUES (?, ?, ?)`;
    db.execute(stmt, [name, address, categories], function (err) {
        if (err) {
            console.error(err);  // Log the error
            return res.status(500).json({ error: 'Failed to save place' });
        }
        res.status(200).json({ success: true, id: this.lastID });
    });
});

// API route to fetch manually added places
app.get('/api/places-manual', (req, res) => {
    db.query("SELECT * FROM submits", (err, rows) => {
        if (err) {
            console.error(err);  // Log the error
            return res.status(500).json({ error: 'Failed to fetch places' });
        }
        res.json(rows);
    });
});

// Fallback route for any other requests, serves the index.html (SPA)
app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'public', 'index.html'));
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});

app.get('/api/places-manual', (req, res) => {
    db.query("SELECT * FROM submits", (err, rows) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Failed to fetch places' });
        }
        res.json(rows);
    });
});
