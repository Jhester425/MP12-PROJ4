document.addEventListener("DOMContentLoaded", async () => {
    const ccaaSelect = document.getElementById("ccaa");
    const provinciaSelect = document.getElementById("provincia");
    const poblacionSelect = document.getElementById("poblacion");
    const submitButton = document.getElementById("submit");
    const imageContainer = document.getElementById("image-container");
    const locationText = document.getElementById("location");
    const descriptionText = document.getElementById("description-text");
    const placesContainer = document.getElementById("places-container");

    const discoverPlacesContainer = document.getElementById("discover-places-container");
    const discoverPlacesGrid = document.getElementById("discover-places-grid");
    const explorePlacesContainer = document.getElementById("explore-places-container");
    const explorePlacesGrid = document.getElementById("explore-places-grid");


    let storedPlaces = []; // Store places data

    // Load CCAA options
    async function loadCCAA() {
        const res = await fetch("https://raw.githubusercontent.com/frontid/ComunidadesProvinciasPoblaciones/refs/heads/master/ccaa.json");
        const ccaaList = await res.json();
        ccaaList.forEach(ccaa => {
            const option = document.createElement("option");
            option.value = ccaa.code;
            option.textContent = ccaa.label;
            ccaaSelect.appendChild(option);
        });
    }

    // Load Provincias based on selected CCAA
    async function loadProvincias(ccaaId) {
        provinciaSelect.innerHTML = '<option value="" disabled selected>Selecciona una opción</option>';
        poblacionSelect.innerHTML = '<option value="" disabled selected>Selecciona una opción</option>';
        provinciaSelect.disabled = true;
        poblacionSelect.disabled = true;

        const res = await fetch("https://raw.githubusercontent.com/frontid/ComunidadesProvinciasPoblaciones/refs/heads/master/provincias.json");
        const provincias = await res.json();
        const filtered = provincias.filter(p => String(p.parent_code) === String(ccaaId));

        if (filtered.length > 0) provinciaSelect.disabled = false;

        filtered.forEach(p => {
            const option = document.createElement("option");
            option.value = p.code;
            option.textContent = p.label;
            provinciaSelect.appendChild(option);
        });
    }

    // Load Poblaciones based on selected Provincia
    async function loadPoblaciones(provinciaId) {
        poblacionSelect.innerHTML = '<option value="" disabled selected>Selecciona una opción</option>';
        poblacionSelect.disabled = true;

        const res = await fetch("https://raw.githubusercontent.com/frontid/ComunidadesProvinciasPoblaciones/refs/heads/master/poblaciones.json");
        const poblaciones = await res.json();
        const filtered = poblaciones.filter(p => p.parent_code == provinciaId);
        if (filtered.length > 0) poblacionSelect.disabled = false;

        filtered.forEach(p => {
            const option = document.createElement("option");
            option.value = p.label;
            option.textContent = p.label;
            poblacionSelect.appendChild(option);
        });
    }

    // Fetch Wikipedia description for selected poblacion
    async function fetchDescription(poblacion) {
        try {
            const res = await fetch(`/api/description?poblacion=${encodeURIComponent(poblacion)}`);
            const data = await res.json();
            descriptionText.textContent = data.extract || "No description available.";
        } catch {
            descriptionText.textContent = "Failed to load description.";
        }
    }

    // Get User's geolocation
    async function getUserLocation() {
        return new Promise((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(
                (pos) => resolve({ lat: pos.coords.latitude, lon: pos.coords.longitude }),
                (err) => reject(err)
            );
        });
    }

    // Fetch and display location info
    async function fetchLocation(poblacion) {
        try {
            const user = await getUserLocation();
            const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(poblacion + ', España')}`);
            const data = await res.json();

            if (data.length > 0) {
                const town = data[0];
                const distance = haversine(user.lat, user.lon, parseFloat(town.lat), parseFloat(town.lon)).toFixed(2);
                locationText.innerHTML = 
                    `<b>Town/City</b><br>Latitude: ${town.lat}<br>Longitude: ${town.lon}<br><br>
                    <b>Your Location</b><br>Latitude: ${user.lat}<br>Longitude: ${user.lon}<br><br>
                    <b>Distance:</b> ${distance} km`;
            } else {
                locationText.textContent = "Location not found.";
            }
        } catch {
            locationText.textContent = "Failed to load location.";
        }

        function haversine(lat1, lon1, lat2, lon2) {
            const R = 6371; // Radius of the Earth in km
            const dLat = (lat2 - lat1) * Math.PI / 180;
            const dLon = (lon2 - lon1) * Math.PI / 180;
            const a = Math.sin(dLat / 2) ** 2 +
                      Math.cos(lat1 * Math.PI / 180) *
                      Math.cos(lat2 * Math.PI / 180) *
                      Math.sin(dLon / 2) ** 2;
            return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        }
    }

    // Fetch nearby places from Geoapify API
    async function fetchGeoapifyPlaces(poblacion) {
        if (!poblacion) return;
    
        discoverPlacesGrid.innerHTML = "<p>Loading nearby places...</p>";
        try {
            const user = await getUserLocation();
            const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(poblacion + ', España')}`);
            const data = await res.json();
            if (data.length === 0) {
                discoverPlacesGrid.innerHTML = "<p>Location not found.</p>";
                return;
            }
    
            const townLat = parseFloat(data[0].lat);
            const townLon = parseFloat(data[0].lon);
    
            const placesRes = await fetch(`/api/geoapify?lat=${townLat}&lon=${townLon}`);
            const placesData = await placesRes.json();
    
            storedPlaces = placesData.features;
            displayPlaces(storedPlaces, discoverPlacesGrid);
        } catch (error) {
            console.error("Geoapify error:", error);
            discoverPlacesGrid.innerHTML = "<p>Error fetching places.</p>";
        }
    }
    

    // Function to display places
    function displayPlaces(places, gridContainer) {
        gridContainer.innerHTML = "";  // Clear target container
        if (places.length === 0) {
            gridContainer.innerHTML = "<p>No se encontraron lugares de interés cercanos.</p>";
        } else {
            places.forEach(place => {
                const info = place.properties || place; // Support both API and SQL formats
                const name = info.name || "(No name)";
                const address = info.address_line1 || info.address || "(No address)";
                const categories = info.categories
                    ? Array.isArray(info.categories)
                        ? info.categories.map(cat => cat.replace(/[\._]/g, ' ')).join(", ")
                        : info.categories
                    : "No especificado";
    
                const div = document.createElement("div");
                div.classList.add("place-item");
                div.setAttribute("data-search", `${name} ${address} ${categories}`.toLowerCase());
    
                div.innerHTML = `
                    <h4>${name}</h4>
                    <p><strong>Address:</strong> ${address}</p>
                    <p><strong>Category:</strong> ${categories}</p>
                `;
    
                gridContainer.appendChild(div);
            });
        }
    }
    

    // Function to fetch places from MySQL and handle them
    async function fetchPlaces() {
        try {
            const response = await fetch('/api/places-manual');
            const places = await response.json();
    
            if (places.length === 0) {
                explorePlacesGrid.innerHTML = 'No places found';
            } else {
                displayPlaces(places, explorePlacesGrid);
            }
        } catch (error) {
            console.error('Error fetching places:', error);
        }
    }
    

    // Call the fetchPlaces function when the page loads
    window.onload = fetchPlaces;

    // Event Listeners
    ccaaSelect.addEventListener("change", () => {
        loadProvincias(ccaaSelect.value);
    });

    provinciaSelect.addEventListener("change", () => {
        loadPoblaciones(provinciaSelect.value);
    });

    submitButton.addEventListener("click", async (e) => {
        e.preventDefault(); // Prevent form submission and page reload
        const poblacion = poblacionSelect.value;
        if (poblacion) {
            await fetchLocation(poblacion);
            await fetchDescription(poblacion);
            await fetchGeoapifyPlaces(poblacion);
        }
    });

    // Init CCAA
    await loadCCAA();

    // Filter logic for places
    const searchInput = document.getElementById("search-input");
    const searchButton = document.getElementById("search-button");

    function filterPlaces(query) {
        const items = discoverPlacesGrid.querySelectorAll(".place-item");
        items.forEach(item => {
            const text = item.getAttribute("data-search");
            item.style.display = text.includes(query) ? "" : "none";
        });
    }

    searchButton.addEventListener("click", (e) => {
        e.preventDefault();
        const query = searchInput.value.trim().toLowerCase();
        filterPlaces(query);
    });

    searchInput.addEventListener("input", () => {
        const query = searchInput.value.trim().toLowerCase();
        filterPlaces(query);
    });

    // ✅ Tab Switching Logic
// ✅ Tab Switching Logic
const tabButtons = document.querySelectorAll(".tab-btn");
const tabPanels = document.querySelectorAll(".tab-panel");

tabButtons.forEach(button => {
    button.addEventListener("click", () => {
        tabButtons.forEach(btn => btn.classList.remove("active"));
        tabPanels.forEach(panel => panel.classList.remove("active"));

        button.classList.add("active");
        const targetPanel = document.getElementById(button.dataset.tab);
        if (targetPanel) targetPanel.classList.add("active");

        // Only fetch places from the database when the "Explore" tab is active
        if (button.dataset.tab === "tab2") {
            fetchPlaces(); // Fetch places only in the Explore tab
        }

        if (button.dataset.tab === "tab3") {
            console.log("Tab 3 active - implement share prompt if needed");
        }
    });
});

document.getElementById("manual-insert-form").addEventListener("submit", async (event) => {
    event.preventDefault(); // Prevent the form from refreshing the page

    const name = document.getElementById("name").value;
    const address = document.getElementById("address").value;
    const categories = document.getElementById("categories").value;

    // Send POST request to save place
    try {
        const response = await fetch('/api/places-manual', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name, address, categories }),
        });

        const result = await response.json();
        if (response.ok) {
            // Display success message
            document.getElementById("success-message").style.display = 'block';
            setTimeout(() => document.getElementById("success-message").style.display = 'none', 3000);

            // Reset the form fields
            document.getElementById("manual-insert-form").reset();
        } else {
            // Display error message
            document.getElementById("error-message").style.display = 'block';
        }
    } catch (error) {
        console.error('Error adding place:', error);
        document.getElementById("error-message").style.display = 'block';
    }
});


});
