const express = require('express');
const path = require('path');
const cors = require('cors');
const axios = require('axios');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3000;

// Enable CORS
app.use(cors());

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, '../public')));

// API route for fetching description from Wikipedia
app.get('/api/description', async (req, res) => {
    const poblacion = req.query.poblacion; // Get town name from query parameter

    if (!poblacion) {
        return res.status(400).json({ error: 'Missing poblacion query parameter' });
    }

    try {
        const response = await axios.get(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(poblacion)}`);
        res.json(response.data);
    } catch (error) {
        console.error(error); // Log the error for debugging purposes
        res.status(500).json({ error: 'Failed to fetch description from Wikipedia' });
    }
});

// API route for fetching data from Geoapify API
app.get('/api/geoapify', async (req, res) => {
    const geoapifyKey = process.env.GEOAPIFY_KEY;  // Get the Geoapify API key from environment variables
    const { lat, lon } = req.query;  // Get latitude and longitude from query parameters
    const categories = "tourism,leisure,accommodation,catering,entertainment";

    // Validate latitude and longitude
    if (!lat || !lon) {
        return res.status(400).json({ error: 'Missing lat or lon query parameter' });
    }

    try {
        let placesData = [];
        let nextUrl = `https://api.geoapify.com/v2/places?categories=${categories}&filter=circle:${lon},${lat},10000&limit=500&apiKey=${geoapifyKey}`;

        // Fetch multiple pages if "next" is present
        while (nextUrl) {
            const response = await axios.get(nextUrl);
            const data = response.data;

            placesData = placesData.concat(data.features); // Append the features to the results

            // Check if there is a next page
            nextUrl = data.next ? data.next : null; // If "next" exists, update the URL for the next request
        }

        // Return all the fetched data
        res.json({ features: placesData });

    } catch (error) {
        console.error('Error fetching from Geoapify:', error);  // Log the error
        res.status(500).json({ error: 'Failed to fetch data from Geoapify' });
    }
});

// Fallback route for any other requests, serves the index.html (SPA)
app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, '../public', 'index.html'));
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
