CREATE DATABASE IF NOT EXISTS explore;

USE explore;

CREATE TABLE IF NOT EXISTS submits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    address TEXT NOT NULL,
    categories TEXT NOT NULL
);
